﻿using System;
using BrokeProtocol.API;

namespace Simple_Contact_Us
{
    public class core : Plugin
    {    
            public core()
            {
                Info = new PluginInfo("Simple_Contact_Us", "scu")
                    {
                        Description = "this plugin is for player can see how can conctact you or join your discord...",
                        Website = "https://www.terratech.xyz"
                    };
            }
       
    }
}