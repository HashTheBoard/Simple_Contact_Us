﻿using System;
using System.IO;
using BrokeProtocol.API;
using BrokeProtocol.Managers;
using UnityEngine;

namespace Simple_Contact_Us
{
    class Reader
    {

		[Target(100, ExecutionMode.Event)]
		public void OnStart(SvManager svManager)
		{
			bool flag = !File.Exists(Reader.Simple_Contact_Us);
			if (flag)
			{
				try
				{
					StreamWriter streamWriter = File.CreateText(Reader.Simple_Contact_Us);
					streamWriter.Close();
					File.AppendAllText(Reader.Simple_Contact_Us, "this is an exemple !" + Environment.NewLine);
					Debug.Log("[SCU] Done!");
				}
				catch (Exception ex)
				{
					Debug.LogError("[SCU txt done !] " + ex.Message);
				}
			}
		}

public static string GetContact()
{
  if (File.Exists(Simple_Contact_Us))
  {
    return File.ReadAllText(Simple_Contact_Us);
  }
  return string.Empty;
}

		private static string Simple_Contact_Us = "Simple_Contact_Us.txt";

	}
}
