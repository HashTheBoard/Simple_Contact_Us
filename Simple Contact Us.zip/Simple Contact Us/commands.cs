﻿using BrokeProtocol.API;
using System;
using BrokeProtocol.Entities;


namespace Simple_Contact_Us
{
    public class commands
    {

        public class Cmd : IScript
        {

           public string result { get; } = Reader.GetContact();
            public Cmd()
            {
                CommandHandler.RegisterCommand("contact", new Action<ShPlayer>(OnCommandInvoke)); 
            }

            public void OnCommandInvoke(ShPlayer player)
            {
                player.svPlayer.SendGameMessage(result);
            }
        }
    }
}